package com.rakuten.prj.instructionsbootapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InstructionsbootappApplication {

	public static void main(String[] args) {
		SpringApplication.run(InstructionsbootappApplication.class, args);
	}

}
